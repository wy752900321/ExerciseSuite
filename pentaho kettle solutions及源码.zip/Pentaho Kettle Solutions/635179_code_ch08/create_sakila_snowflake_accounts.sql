CREATE USER sakila_snowflake IDENTIFIED BY 'sakila_snowflake';
GRANT ALL PRIVILEGES ON sakila_snowflake.* TO sakila_snowflake;
