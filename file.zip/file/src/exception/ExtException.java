package exception;

public class ExtException extends Exception {

	public ExtException() {
		// TODO Auto-generated constructor stub
	}

	public ExtException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ExtException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ExtException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
